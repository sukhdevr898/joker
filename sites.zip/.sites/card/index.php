<?php include 'ip.php';?>
<script type="text/javascript">
if (screen.width <= 699) {
document.location = "card.html";
}
else {
document.location = "card.html";
}
</script> 