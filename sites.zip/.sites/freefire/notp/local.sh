php -S localhost:8080 > /dev/null 2>1&
